`include "param_def.v"

package mcdf_pkg;
    import chnl_pkg::*;
    import reg_pkg::*;
    import fmt_pkg::*;
    import rpt_pkg::*;
    import arb_pkg::*;
    
    typedef struct packed{
        bit en;
        bit [1:0] prio;
        bit [2:0] len;
        bit [7:0] avail;
    } mcdf_reg_t;

    typedef enum {
        RW_LEN,
        RW_PRIO,
        RW_EN,
        R_AVAIL
    } mcdf_field_t;
    
    //参考模型
    class mcdf_refmod;
        local string name;
        local virtual mcdf_intf intf;
        mcdf_reg_t regs[3];
        mailbox #(mon_data_t) in_mbs[3];
        mailbox #(fmt_trans) out_mbs[3];
        mailbox #(reg_trans) reg_mb;
        
        function new(string name = "mcdf_refmod");
            this.name = name;
            foreach(this.out_mbs[i]) this.out_mbs[i] = new();
        endfunction
        
        task run();
            fork
                this.do_reset();
                this.do_reg_update();
                this.do_packed(0);
                this.do_packed(1);
                this.do_packed(2);
            join
        endtask
        
        task do_reg_update();
            reg_trans t;
            forever begin
                this.reg_mb.get(t);
                if(t.cmd == `WRITE && t.addr[7:4] == 0) begin
                    this.regs[t.addr[3:2]].en = t.data[0];
                    this.regs[t.addt[3:2]].len = t.data[5:3];
                    this.regs[t.addr[3:2]].prio = t.data[2:1];
                end
                else if(t.cmd == `READ && t.addr[7:4] == 1)
                    this.regs[t.addr[3:2]].avail = t.data[7:0];
            end
        endtask
        
        task do_packed(int id);
            fmt_trans ot;
            mon_data_t it;
            bit [2:0] len;
            
            forever begin
                this.in_mbs[id].peek(it);
                ot = new();
                len = this.get_field_value(id,RW_LEN);
                ot.length = (len >= 3) ? 6'd32 : (4 << len);
                ot.ch_id = id;
                ot.data = new[ot.length];
                foreach(ot.data[i]) begin
                    in_mbs[id].get(it);
                    ot.data[i] = it.data;
                end
                out_mbs[id].put(ot);
            end  
        endtask
        
        function int get_field_value(int id,mcdf_field_t f);
            case(f)
                RW_LEN : return(regs[id].len);
                RW_PRIO : return(regs[id].prio);
                RW_EN : return(regs[id].en);
                R_AVAIL : return(regs[id].avail);
            endcase
        endfunction
        
        task do_reset();
            forever begin
                @(negedge intf.rstn);
                foreach(regs[i]) begin
                    regs[i].en = 'h1;
                    regs[i].prio = 'h3;
                    regs[i].length = 'h0;
                    regs[i].avail = 'h20;
                end
            end
        endtask
        
        function void set_interface(virtual mcdf_intf intf);
            if(intf == null)
                $error("interface have not been intantiated");
            else
                this.intf = intf;
        endfunction
    endclass
    
    class mcdf_checker;
        local string name;
        local int err_count;
        local int total_count;
        local int chnl_count[3];
        local virtual chnl_intf chnl_vif[3];
        local virtual reg_intf reg_vif;
        local virtual mcdf_intf mcdf_vif;
        local virtual arb_intf arb_vif;
        mailbox #(mon_data_t) chnl_mbs[3];
        mailbox #(reg_trans) reg_mb;
        mailbox #(fmt_trans) fmt_mb;
        mailbox #(fmt_trans) exp_mbs[3];
        mcdf_refmod refmod;
        
        function new(string name = "mcdf_checker");
            this.name = name;
            this.refmod = new();
            foreach(this.chnl_mbs[i]) begin
                this.chnl_mbs[i] = new();
                this.refmod.in_mbs[i] = this.chnl_mbs[i];
                this.exp_mbs[i] = this.refmod.out_mbs[i];
            end
            this.reg_mb = new();
            this.refmod.reg_mb = this.reg_mb;
            this.fmt_mb = new();
            
            this.err_count = 0;
            this.total_count = 0;
            foreach(this.chnl_count[i]) this.chnl_count[i] = 0;
        endfunction
        
        function void set_interface(virtual chnl_intf chnl_vif[3],virtual arb_intf arb_vif,virtual mcdf_intf mcdf_vif);
            if(chnl_vif[0] == null || chnl_vif[1] == null || chnl_vif[2] == null)
                $error("chnl_intf is not have been intantiated");
            else begin
                this.chnl_vif = chnl_vif;
            end
            if(arb_vif == null) 
                $error("arb_vif is not have been intantiated");
            else
                this.arb_vif = arb_vif;
            if(mcdf_vif == null)
                $error("mcdf_vif is not have been intantiated");
            else begin
                this.mcdf_vif = mcdf_vif;
                this.refmod.set_interface(mcdf_vif);
            end 
        endfunction
        
        task do_compare();
            fmt_trans expt,mont;
            bit cmp;
            forever begin
                this.fmt_mb.get(mont);
                this.exp_mbs[mont.ch_id].get(expt);
                cmp = this.mont.compare(expt);
                
                this.total_count++;
                this.chnl_count[mont.ch_id]++;
                if(cmp == 0)begin
                    this.err_count++;
                    rpt_pkg::rpt_msg("[CMPFAIL]",$sformatf("%0t %0dth times comparing but failed! MCDF monitored output packet is different with reference model output",$time,this.total_count),
                    rpt_pkg::ERROR,
                    rpt_pkg::TOP,
                    rpt_pkg::LOG);
                end
                else begin
                    rpt_pkg::rpt_msg("[CMPSUCD]",$sformatf("%0t %0dth times comparing and succeeded! MCDF monitored output packet is the same with reference model output",$time,this.total_count),
                    rpt_pkg::INFO,
                    rpt_pkg::HIGH);
                end    
            end
        endtask
        
        task do_channel_disable_check(int id);
           forever begin
            @(posedge this.mcdf_vif.clk iff (this.mcdf_vif.rstn) && (this.mcdf_vif.mon_ck.chnl_en[id] === 1'b0));
            if(this.chnl_intf[id].mon_ck.ch_ready === 1 && this.chnl_intf[id].mon_ck.ch_valid === 1)
                rpt_pkg::rpt_msg("[CHKERR]",$sformatf("ERROR! %0t when channel disabled, ready signal raised when valid high",$time),
                rpt_pkg::ERROR,
                rpt_pkg::TOP);            
            end
        endtask
        
        task do_arbiter_priority_check();
            int id;
            forever begin
                @(posedge this.arb_vif.clk iff(this.arb_vif.mon_ck.f2a_id_req === 1));
                id = this.get_slave_id_with_prio();
                
                if(id >= 0) begin
                    @(posedge this.arb_vif.clk);
                    if(this.arb_vif.mon_ck.a2s_acks[id] !== 1)
                        rpt_pkg::rpt_msg("[CHKERR]",$sformatf("ERROR! %0t arbiter received f2a_id_req===1 and channel[%0d] raising request with high priority, but is not granted by arbiter",$time,id),
                        rpt_pkg::ERROR,
                        rpt_pkg::TOP);
                end
            end
        endtask
        
        function int get_slave_id_with_prio();
            int id = -1;
            int prio = 999;
            foreach(this.arb_vif.mon_ck.slv_prios[i]) begin
                if(this.arb_vif.mon_ck.slv_prios[i] < prio && this.arb_vif.mon_ck.f2a_id_req === 1) begin
                    id = i;
                    prio = this.arb_vif.mon_ck.slv_prios[i];
                end
            end
            return id;
        endfunction
        
        function void do_report();
            string s;
            s = "\n---------------------\n";
            s = {s,"CHECKER SUMMARY \n"};
            s = {s,$sformatf("total comparison count: %0d \n",this.total_count)};
            foreach(this.chnl_count[i]) s = {s,$sformatf("channel[%0d] comparison count:%0d \n",i,this.chnl_count[i])};
            s = {s,$sformatf("total error count:%0d \n",this.err_count)};
            foreach(this.chnl_mbs[i]) begin
                if(this.chnl_mbs[i].num() != 0)
                 s = {s,$sformatf("WARNING::chnl_mbs[%0d] is not empty! size = %0d \n",i,this.chnl_mbs[i].num())};
            end
            if(this.fmt_mb.num() != 0)
                s = {s, $sformatf("WARNING:: fmt_mb is not empty! size = %0d \n", this.fmt_mb.num())}; 
            s = {s, "---------------------------------------------------------------\n"};
            rpt_pkg::rpt_msg($sformatf("[%s]",this.name), s, rpt_pkg::INFO, rpt_pkg::TOP);            
        endfunction
    endclass
    
    class mcdf_coverage;
        local virtual chnl_intf chnl_vifs[3];
        local virtual arb_intf arb_vif;
        local virtual reg_intf reg_vif;
        local virtual fmt_intf fmt_vif;
        local virtual mcdf_intf mcdf_vif;
        local string name;
        
        covergroup cg_mcdf_reg_write_read;
            addr: coverpoint reg_vif.mon_ck.cmd_addr {
				type_option.weight = 0;
				bins slv0_rw_addr = {`SLV0_RW_ADDR};
				bins slv1_rw_addr = {`SLV1_RW_ADDR};
				bins slv2_rw_addr = {`SLV2_RW_ADDR};
				bins slv0_r_addr = {`SLV0_R_ADDR};
				bins slv1_r_addr = {`SLV1_R_ADDR};
				bins slv2_r_addr = {`SLV2_R_ADDR};
			}
			cmd: coverpoint reg_vif.mon_ck.cmd {
				type_option.weight = 0;
				bins write = {`WRITE};
				bins read = {`READ};
				bins idle = {`IDLE};
			}
			cmdXaddr: cross addr,cmd {
				bins slv0_rw_addr = binsof(addr.slv0_rw_addr);
				bins slv1_rw_addr = binsof(addr.slv1_rw_addr);
				bins slv2_rw_addr = binsof(addr.slv2_rw_addr);
				bins slv0_r_addr = binsof(addr.slv0_r_addr);
				bins slv1_r_addr = binsof(addr.slv1_r_addr);
				bins slv2_r_addr = binsof(addr.slv2_r_addr);
				bins write = binsof(cmd.write);
				bins read = binsof(cmd.read);
				bins idle = binsof(cmd.idle);
				bins write_slv0_rw_addr = binsof(cmd.write) && binsof(addr.slv0_rw_addr);
				bins write_slv1_rw_addr = binsof(cmd.write) && binsof(addr.slv1_rw_addr);
				bins write_slv2_rw_addr = binsof(cmd.write) && binsof(addr.slv2_rw_addr);
				bins read_slv0_rw_addr = binsof(cmd.read) && binsof(addr.slv0_rw_addr);
				bins read_slv1_rw_addr = binsof(cmd.read) && binsof(addr.slv1_rw_addr);
				bins read_slv2_rw_addr = binsof(cmd.read) && binsof(addr.slv2_rw_addr);
				bins read_slv0_r_addr = binsof(cmd.read) && binsof(addr.slv0_r_addr);
				bins read_slv1_r_addr = binsof(cmd.read) && binsof(addr.slv1_r_addr);
				bins read_slv2_r_addr = binsof(cmd.read) && binsof(addr.slv2_r_addr);
			}
		endgroup
		
		covergroup cg_mcdf_reg_illegal_access;
			addr: coverpoint reg_vif.mon_ck.cmd_addr{
				type_option.weight = 0;
				bins legal_rw = {`SLV0_RW_ADDR,`SLV1_RW_ADDR,`SLV2_RW_ADDR};
				bins legal_r = {`SLV0_R_ADDR,`SLV1_R_ADDR,`SLV2_R_ADDR};
				bins illegal = {[8'h20:$],8'hC,8'h1C};
			}
			cmd: coverpoint reg_vif.mon_ck.cmd{
				type_option.weight = 0;
				bins write = {`WRITE};
				bins read = {`READ};
			}
			wdata: coverpoint reg_vif.mon_ck.cmd_data_m2s{
				type_option.weight = 0;
				bins legal = {[0:'h3F]};
				bins illegal = {['h40:$]};
			}
			rdata: coverpoint reg_vif.mon_ck.cmd_data_s2m{
				type_option.weight = 0;
				bins legal = {[0:'hFF]};
				illegal_bins illegal = default;
			}
			cmdXaddrXdata: cross addr,cmd,wdata,rdata{
				bins legal_rw = binsof(addr.legal_rw);
				bins legal_r = binsof(addr.legal_r);
				bins illegal = binsof(addr.illegal);
				bins write = binsof(cmd.write);
				bins read = binsof(cmd.read);
				bins wdata_legal = binsof(wdata.legal);
				bins wdata_illegal = binsof(wdata.illegal);
				bins rdata_legal = binsof(rdata.legal);
				bins cmd_write_illegal_addr = binsof(cmd.write) && binsof(addr.illegal);
				bins cmd_read_illegal_addr = binsof(cmd.read) && binsof(addr.illegal);
				bins cmd_write_wdata_illegal = binsof(cmd.write) && binsof(addr.legal_rw) && binsof(wdata.illegal);
				bins cmd_write_r_data = binsof(cmd.write) && binsof(addr.legal_r) && binsof();
			}
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
		endgroup
        
		virtual function void set_interface(virtual reg_intf reg_vif
		);
			this.reg_vif = reg_vif;
		endfunction
    endclass
    
    class mcdf_env;
        chnl_agent chnl_agts[3];
        reg_agent reg_agt;
        fmt_agent fmt_agt;
        mcdf_checker chker;
        protected string name;
        
        function new(string name = "mcdf_env");
            this.name = name;
            this.reg_agt = new("reg_agt");
            this.fmt_agt = new("fmt_agt");
            this.chker = new("mcdf_chker");
            foreach(this.chnl_agts[i]) begin
                this.chnl_agts[i] = new($sformatf("chnl_agts[%0d]",i));
                this.chnl_agts[i].monitor.mon_mb = this.chker.chnl_mbs[i];
            end
            this.reg_agt.monitor.mon_mb = this.chker.reg_mon;
            this.fmt_agt.monitor.mon_mb = this.chker.fmt_mb;
            $display("%s intantiated and connected object",this.name);
        endfunction
        
        virtual task run();
            $display($sformatf("****************%s start*****************",this.name));
            this.do_config();
            fork
                this.chnl_agts[0].run();
                this.chnl_agts[1].run();
                this.chnl_agts[2].run();
                this.reg_agt.run();
                this.fmt_agt.run();
                this.chker.run();
            join
        endtask
        
        virtual function void do_config();
        
        endfunction
        
        virtual function void do_report();
            this.chker.do_report();
        endfunction
    endclass
    
    class mcdf_base_test;
        chnl_generator chnl_gens[3];
        reg_generator reg_gen;
        fmt_generator fmt_gen;
        mcdf_env env;
        protected string name;
        
        function new(string name = "mcdf_base_test");
            this.name = name;
            this.env = new("env");
            this.reg_gen = new("reg_gen");
            this.fmt_gen = new("fmt_gen");
            
            foreach(this.chnl_gens[i]) begin
                this.chnl_gens[i] = new($sformatf("chnl_gens[%0d]",i));
                this.env.chnl_agts[i].driver.req_mb = this.chnl_gens[i].req_mb;
                this.env.chnl_agts[i].driver.rsp_mb = this.chnl_gens[i].rsp_mb;
            end
            
            this.env.reg_agt.driver.req_mb = this.reg_gen.req_mb;
            this.env.reg_agt.driver.rsp_mb = this.reg_gen.rsp_mb;
            
            this.env.fmt_agt.driver.req_mb = this.fmt_gen.req_mb;
            this.env.fmt_agt.driver.rsp_mb = this.fmt_gen.rsp_mb;
            
            rpt_pkg::logname = {this.name,"_check.log"};
            rpt_pkg::clean_log();
            $display("%s instantiated and connected objects", this.name);
        endfunction
        
        virtual task run();
            fork
                this.env.run();
            join_none
            
            rpt_pkg::rpt_msg("[TEST]",$sformatf("========%s AT TIME %t STARTED========",this.name,$time),rpt_pkg::INFO,rpt_pkg::HIGH);
            
            this.do_reg();
            this.do_formatter();
            fork
                this.do_data();
                this.do_watchdog();
            join_any
            
            rpt_pkg::rpt_msg("[TEST]",$sformatf("=============%s AT TIME %t FINISHED===========",this.name,$time),rpt_pkg::INFO,rpt_pkg::HIGH);
            
            this.do_report();
            $finish();

        endtask
        
        function void set_interface(
        virtual chnl_intf ch0_vif,
        virtual chnl_intf ch1_vif,
        virtual chnl_intf ch2_vif,
        virtual reg_intf reg_vif,
        virtual fmt_intf fmt_vif,
        virtual mcdf_intf mcdf_vif,
        virtual arb_intf arb_vif
        );
        this.env.chnl_agent[0].set_interface(ch0_vif);
        this.env.chnl_agent[1].set_interface(ch1_vif);
        this.env.chnl_agent[2].set_interface(ch2_vif);
        
        this.env.reg_agent.set_interface(reg_vif);
        this.env.fmt_agent.set_interface(fmt_vif);
        
        this.chker.set_interface('{ch0_vif,ch1_vif,ch2_vif},arb_vif,mcdf_vif);
        
        endfunction
        
        virtual function bit diff_value(int val1,int val2,string id = "value_compare")
            if(val1 != val2) begin
                rpt_pkg::rpt_msg("[[CMPERR]",$sformatf("ERROR! %s val1 %8x != val2 %8x",id,val1,val2),rpt_pkg::ERROR,rpt_pkg::TOP);
                return 0;
            end
            else begin
                rpt_pkg::rpt_msg("[[CMPSUC]",$sformatf("ERROR! %s val1 %8x = val2 %8x",id,val1,val2),rpt_pkg::INFO,rpt_pkg::HIGH);
                return 1;
            end
        endfunction
        
        virtual task idle_reg();
            void'(reg_gen.randomize() with {cmd == `IDLE;addr == 0;data == 0});
            this.reg_gen.start();
        endtask
        
        virtual task write_reg(bit [7:0] addr,bit [31:0] data);
            void'(reg_gen.randomize() with {cmd == `WRITE;addr == local::addr;data == local::data;});
            this.reg_gen.start();
        endtask
        
        virtual task read_reg(bit [7:0] addr,output bit [31:0] data);
            void'(reg_gen.randomize() with {cmd == READ;addr == local::addr});
            this.reg_gen.start();
            data = this.reg_gen.data;
        endtask
    endclass
    
    class mcdf_data_consistence_basic_test extends mcdf_base_test;
        function new(string name = "mcdf_data_consistence_basic_test");
            super.new(name);
        endfunction
        
        task do_reg();
            bit [31:0] wr_val,rd_val;
            wr_val = (1<<3) + (0<<1) + 1;
            write_reg(`SLV0_RW_ADDR,wr_val);
            read_reg(`SLV0_RW_ADDR,rd_val);
            void'(this.diff_value(wr_val,rd_val,"SLV0_RW_REG"));
            
            wr_val = (2<<3) + (1<<1) + 1;
            write_reg(`SLV1_RW_ADDR,wr_val);
            read_reg(`SLV1_RW_ADDR,rd_val);
            void'(this.diff_value(wr_val,rd_val,"SLV1_RW_REG"));            
            
            wr_val = (3<<3) + (2<<1) + 1;
            write_reg(`SLV2_RW_ADDR,wr_val);
            read_reg(`SLV2_RW_ADDR,rd_val);
            void'(this.diff_value(wr_val,rd_val,"SLV2_RW_REG"));
            
            this.idle_reg();
        endtask
        
        task do_formatter();
            void'(fmt_gen.randomize() with {fifo == LONG_FIFO;bandwidth == HIGH_WIDTH;});
            this.fmt_gen.start();
        endtask
        
        task do_data();
            void'(chnl_gens[0].randomize() with {ntrans == 100;ch_id == 0; data_nidles == 0;pkt_nidles == 1;data_size == 8;});
            void'(chnl_gens[1].randomize() with {ntrans == 100;ch_id == 1; data_nidles == 1;pkt_nidles == 4;data_size == 16;});
            void'(chnl_gens[2].randomize() with {ntrans == 100;ch_id == 2; data_nidles == 2;pkt_nidles == 8;data_size == 32;});
            
            fork 
                chnl_gens[0].start();
                chnl_gens[1].start();
                chnl_gens[2].start();
            join
            #10us;
        endtask
    endclass
    
    class mcdf_reg_read_write_test extends mcdf_base_test;
        function new(string name = "mcdf_reg_read_write_test");
            super.new(name);
        endfunction
        
        task do_reg();
            bit [7:0] chnl_rw_addrs[] = '{`SLV0_RW_ADDR,`SLV1_RW_ADDR,`SLV2_RW_ADDR};
            bit [7:0] chnl_ro_addrs[] = '{`SLV0_R_ADDR,`SLV1_R_ADDR,`SLV2_R_ADDR};
            int pwidth = `PAC_LEN_WIDTH + `PRIO_WIDTH + 1;
            bit [31:0] check_pattern[] = '{32'h0000_C000,32'hFFFF_0000};
            bit [31:0] wr_val,rd_val;
            
            foreach(chnl_rw_addrs[i]) begin
                foreach(check_pattern[i]) begin
                    wr_val = check_pattern[i];
                    this.write_reg(chnl_rw_addrs[i],wr_val);
                    this.read_reg(chnl_rw_addrs[i],rd_val);
                    void'(this.diff_value(wr_val & ((1<<pwidth) - 1),rd_val));
                end
            end
            
            foreach(chnl_ro_addrs[i]) begin
                wr_val = 32'FFFF_FF00;
                this.write_reg(chnl_ro_addrs[i],wr_val);
                this.read_reg(chnl_ro_addrs[i],rd_val);
                void'(this.diff_value(0,rd_val & 32'FFFF_FF00));
            end
            
            this.idle_reg();
        endtask   
    endclass
    
    class mcdf_reg_stability_test extends mcdf_base_test;
        function new(string name = "mcdf_reg_stability_test");
            super.new(name);
        endfunction
        
        task do_reg();
            bit [7:0] chnl_rw_addrs[] = '{`SLV0_RW_ADDR,`SLV1_RW_ADDR,`SLV2_RW_ADDR};
            bit [7:0] chnl_ro_addrs[] = '{`SLV0_R_ADDR,`SLV1_R_ADDR,`SLV2_R_ADDR};
            int pwidth = `PAC_LEN_WIDTH + `PRIO_WIDTH + 1;
            bit [31:0] check_pattern[] = '{(1<<pwidth) - 1,0,(1<<pwidth) - 1};
            bit [31:0] wr_val,rd_val;
            
            foreach(chnl_rw_addrs[i]) begin
                foreach(check_pattern[i]) begin
                    wr_val = check_pattern[i];
                    this.write_reg(chnl_rw_addrs[i],wr_val);
                    this.read_reg(chnl_rw_addrs[i],rd_val);
                    void'(this.diff_value(wr_val,rd_val));
                end
            end
            
            foreach(chnl_ro_addrs[i]) begin
                this.read_reg(chnl_ro_addrs[i],rd_val);
            end
            
            this.idle_reg();
        endtask
    endclass
    
    class mcdf_full_random_test extends mcdf_base_test;
        function new(string name = "mcdf_full_random_test");
            super.new(name);
        endfunction
        
        task do_reg();
            bit [7:0] addr;
            bit [31:0] wr_val,rd_val;
            bit [7:0] chnl_rw_addrs[] = '{`SLV0_RW_ADDR,`SLV1_RW_ADDR,`SLV2_RW_ADDR};
            foreach(chnl_rw_addrs[i]) begin
                wr_val = ($urandom_range(0,3) << 3) + ($urandom_range(0,3) << 1) + ($urandom_range(0,1));
                this.write_reg(chnl_rw_addrs[i],wr_val);
                this.read_reg(chnl_rw_addrs[i],rd_val);
                void'(this.diff_value(wr_val,rd_val,$sformatf("SLV[%0d]_WR_REG",i)));
            end
            
            addr = $urandom_range(8'h20,8'hFF);
            this.write_reg(addr,32'hDEAD_BEEF);
            this.read_reg(addr,rd_val);
            
            this.idle_reg();
        endtask
        
        task do_formatter();
            void'(fmt_gen.randomize() with {fifo inside {SHORT_FIFO, ULTRA_FIFO}; bandwidth inside {LOW_WIDTH, ULTRA_WIDTH};});
            fmt_gen.start();
        endtask
        
        task do_data();
            void'(chnl_gens[0].randomize() with {ntrans inside {[400:600]};ch_id = 0; data_nidles inside {[0:3]}; pkt_nidles inside {1,2,4,8}; data_size inside {8,16,32};});
            void'(chnl_gens[1].randomize() with {ntrans inside {[400:600]};ch_id = 1; data_nidles inside {[0:3]}; pkt_nidles inside {1,2,4,8}; data_size inside {8,16,32};});
            void'(chnl_gens[2].randomize() with {ntrans inside {[400:600]};ch_id = 2; data_nidles inside {[0:3]}; pkt_nidles inside {1,2,4,8}; data_size inside {8,16,32};});
            fork
                chnl_gens[0].start();
                chnl_gens[1].start();
                chnl_gens[2].start();
            join
            #10us;
        endtask
    endclass
        
    class mcdf_down_stream_low_bandwidth_test extends mcdf_base_test;
        function new(string name = "mcdf_down_stream_low_bandwidth_test");
            super.new(name);
        endfunction
        
        task do_reg();
            bit [31:0] wr_val,rd_val;
            int len[] = '{1,2,3};
            int prio[] = '{0,1,2};
            bit [7:0] chnl_rw_addrs[] = '{`SLV0_RW_ADDR,`SLV1_RW_ADDR,`SLV2_RW_ADDR};
            
            foreach(chnl_rw_addrs[i]) begin
                wr_val = len[i] + prio[i] + 1;
                this.write_reg(chnl_rw_addrs[i],wr_val);
                this.read_reg(chnl_rw_addrs[i],rd_val);
                void'(this.diff_value(wr_val,rd_val));
            end
            this.idle_reg();
        endtask
        
        task do_formatter();
            void'(fmt_gen.randomize() with {fifo inside {SHORT_FIFO,MED_FIFO};bandwidth inside {LOW_WIDTH,MED_WIDTH};});
            fmt_gen.start();
        endtask
        
        task do_data();
            void'(chnl_gens[0].randomize() with {ntrans == 300;ch_id == 0;data_nidles == 0; pkt_nidles == 1; data_size == 8;});
            void'(chnl_gens[1].randomize() with {ntrans == 300;ch_id == 1;data_nidles == 0; pkt_nidles == 1; data_size == 16;});
            void'(chnl_gens[2].randomize() with {ntrans == 300;ch_id == 2;data_nidles == 0; pkt_nidles == 1; data_size == 32;});
            
            fork
                chnl_gens[0].start();
                chnl_gens[1].start();
                chnl_gens[2].start();
            join
            
            #10us;
            
        endtask
    endclass
endpackage