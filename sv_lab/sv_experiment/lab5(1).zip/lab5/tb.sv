`timescale 1ns/1ps

interface reg_intf(input clk,input rstn);
	logic [1:0] cmd;
	logic [`ADDR_WIDTH-1:0] cmd_addr;
	logic [`CMD_DATA_WIDTH-1:0] cmd_data_s2m;
	logic [`CMD_DATA_WIDTH-1:0] cmd_data_m2s;
	
	clocking drv_ck @(posedge clk);
		default input #1ns output #1ns;
		output cmd,cmd_data_m2s,cmd_addr;
		input cmd_data_s2m;
	endclocking
	
	clocking mon_ck @(posedge clk);
		default input #1ns output #1ns;
		input cmd,cmd_addr,cmd_data_m2s,cmd_data_s2m;
	endclocking
endinterface